import { Component, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MediaMatcher } from "@angular/cdk/layout";
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-admin-nav-proveedor',
  standalone: true,
  imports: [MatToolbarModule, MatSidenavModule, MatListModule, MatIconModule],
  templateUrl: './admin-nav-proveedor.component.html',
  styleUrls: ['./admin-nav-proveedor.component.scss']
})
export class AdminNavProveedorComponent  {

  opened = true;
  mode = "side"



}
